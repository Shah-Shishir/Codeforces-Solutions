/***

#include <iostream>
#include <algorithm>
using namespace std;

int main ()
{
    int arr[3],i,k=0;

    for (i=0; i<3; i++)
        cin >> arr[i];

    sort (arr,arr+i);

    for (i=0; i<3; i++)
        k = k + abs(arr[i] - arr[1]);

    cout << k << endl;

    return 0;
}

***/

#include <iostream>
using namespace std;

int main ()
{
    int a,b,c,maximum,minimum;

    while (cin >> a >> b >> c)
    {
        maximum = max (max (a,b),c);
        minimum = min (min (a,b),c);

        cout << maximum - minimum << endl;
    }

    return 0;
}
