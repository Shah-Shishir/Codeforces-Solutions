#include <iostream>
using namespace std;

int main ()
{
    int n;

    while (cin >> n)
        cout << ++n << endl;

    return 0;
}
