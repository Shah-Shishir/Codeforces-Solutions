#include <bits/stdc++.h>
using namespace std;

int main ()
{
	int m,n,product,quotient;

	cin >> m >> n;

	product = m*n;
	quotient = product/2;

	cout << quotient << endl;

	return 0;
}
