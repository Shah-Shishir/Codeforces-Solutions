/***

            Bismillahir Rahmanir Rahim
            Read in the name of Allah, who created you!!!
            Author : Shah Newaj Rabbi Shishir,
            Department of CSE, City University, Bangladesh.

***/

import java.util.Scanner;
import java.math.BigInteger;

public class Main
{
	public static void main (String args[])
	{
		Scanner in = new Scanner (System.in);

		long a,b,i;

		while (in.hasNext())
		{
			a = in.nextLong();
			b = in.nextLong();

			if (a == b)
				System.out.println(1);
			else if (a == b-1)
				System.out.println(b%10);
			else
			{
				BigInteger ans = BigInteger.valueOf(1),m=BigInteger.valueOf(0);

				for (i=a+1; i<=b; i++)
				{
					ans = ans.multiply(BigInteger.valueOf(i));
					m = ans.mod(BigInteger.valueOf(10));

					if (m.equals(BigInteger.valueOf(0)))
						break;
				}

				System.out.println(m);
			}
		}
	}
}